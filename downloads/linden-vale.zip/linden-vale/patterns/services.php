<?php
/**
 * Title: Numbered services grid
 * Slug: linden-vale/services
 * Categories: linden-vale, text
 * Description: Swiss-style numbered grid of six pharmacy services.
 */
$lv_services = array(
	array( '01', __( 'Prescription refills', 'linden-vale' ), __( 'Request refills online, by phone, or at the counter. Most are ready the same day.', 'linden-vale' ) ),
	array( '02', __( 'Prescription transfers', 'linden-vale' ), __( 'Moving from another pharmacy? We handle the call so you don\'t have to.', 'linden-vale' ) ),
	array( '03', __( 'Vaccinations', 'linden-vale' ), __( 'Flu, COVID-19, shingles, Tdap and travel vaccines. Book ahead or walk in.', 'linden-vale' ) ),
	array( '04', __( 'Medication reviews', 'linden-vale' ), __( 'A private 15-minute review with a pharmacist covering every medicine you take.', 'linden-vale' ) ),
	array( '05', __( 'Blister packaging', 'linden-vale' ), __( 'Weekly packs sorted by day and time.', 'linden-vale' ) ),
	array( '06', __( 'Local delivery', 'linden-vale' ), __( 'Free delivery within the neighborhood on weekdays.', 'linden-vale' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"align":"wide","className":"lv-mono"} -->
<p class="alignwide lv-mono">01 / Services</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"align":"wide"} -->
<h2 class="wp-block-heading alignwide">Everything you need from a pharmacy.</h2>
<!-- /wp:heading -->
<?php foreach ( array_chunk( $lv_services, 3 ) as $lv_row ) : ?>
<!-- wp:columns {"align":"wide","className":"lv-cells"} -->
<div class="wp-block-columns alignwide lv-cells"><?php foreach ( $lv_row as $lv_s ) : ?><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"lv-mono"} -->
<p class="lv-mono"><?php echo esc_html( $lv_s[0] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html( $lv_s[1] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color"><?php echo esc_html( $lv_s[2] ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><?php endforeach; ?></div>
<!-- /wp:columns -->
<?php endforeach; ?></div>
<!-- /wp:group -->
