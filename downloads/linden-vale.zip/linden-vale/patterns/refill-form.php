<?php
/**
 * Title: Refill request form (demo)
 * Slug: linden-vale/refill-form
 * Categories: linden-vale
 * Description: Accessible refill-request form UI. Demo only: it posts nowhere. Connect it to a HIPAA-compliant refill portal or form service before launch.
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"className":"lv-demo"} -->
<p class="lv-demo"><strong>Demo form.</strong> It doesn't send or store anything. A live build would post to the pharmacy's HIPAA-compliant refill portal over HTTPS.</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<form class="lv-form" data-lv-demo novalidate>
<fieldset><legend>Patient</legend><div class="row"><div class="f"><label for="lv-fn">First name</label><input id="lv-fn" autocomplete="given-name" required></div><div class="f"><label for="lv-ln">Last name</label><input id="lv-ln" autocomplete="family-name" required></div></div>
<div class="row"><div class="f"><label for="lv-dob">Date of birth</label><input id="lv-dob" type="date" required></div><div class="f"><label for="lv-tel">Mobile number</label><input id="lv-tel" type="tel" autocomplete="tel" required><p class="hint">We text you when it's ready.</p></div></div></fieldset>
<fieldset><legend>Prescriptions</legend><div class="f"><label for="lv-rx">Rx number(s)</label><textarea id="lv-rx" aria-describedby="lv-rxh" required></textarea><p class="hint" id="lv-rxh">One per line. It's printed on your label, above the barcode.</p></div></fieldset>
<fieldset><legend>Pickup</legend><div class="row"><div class="f"><label for="lv-how">Method</label><select id="lv-how"><option>Pick up in store</option><option>Local delivery</option></select></div><div class="f"><label for="lv-when">Preferred day</label><input id="lv-when" type="date"></div></div>
<div class="f"><label class="check"><input type="checkbox" required> I understand this is a demo form and won't enter real health information.</label></div></fieldset>
<button type="submit">Submit refill request</button><p class="lv-notice" role="status" aria-live="polite"></p></form>
<!-- /wp:html --></div>
<!-- /wp:group -->
