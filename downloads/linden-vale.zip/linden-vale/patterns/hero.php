<?php
/**
 * Title: Pharmacy hero with task shortcuts
 * Slug: linden-vale/hero
 * Categories: linden-vale, banner
 * Description: Headline, intro, three task shortcuts (refill, transfer, vaccines) and a hero image.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}},"border":{"bottom":{"color":"var:preset|color|line","width":"1px"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--line);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"lv-mono"} -->
<p class="lv-mono">Independent pharmacy · Open today 8–8</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Care that knows your name.</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"large"} -->
<p class="has-muted-color has-text-color has-large-font-size">Refills ready the same day, vaccines without the wait, and pharmacists who take time to answer your questions.</p>
<!-- /wp:paragraph -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"12px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"className":"lv-task"} -->
<div class="wp-block-column lv-task"><!-- wp:paragraph -->
<p><a href="/refill/"><strong>Refill →</strong></a><br>Request online in 2 minutes</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"className":"lv-task"} -->
<div class="wp-block-column lv-task"><!-- wp:paragraph -->
<p><a href="/contact/"><strong>Transfer →</strong></a><br>We call your old pharmacy</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"className":"lv-task"} -->
<div class="wp-block-column lv-task"><!-- wp:paragraph -->
<p><a href="/vaccines/"><strong>Vaccines →</strong></a><br>Book a time that suits you</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"6px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/pharmacy-hero.webp' ) ); ?>" alt="<?php esc_attr_e( 'Bright pharmacy counter with a pharmacist arranging shelves', 'linden-vale' ); ?>" style="border-radius:6px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
