<?php
/**
 * Title: Booking widget embed
 * Slug: linden-vale/booking-embed
 * Categories: linden-vale
 * Description: Vaccine list beside an iframe slot for a third-party scheduling widget. Ships with a demo widget; swap in the provider's embed code.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading -->
<h2 class="wp-block-heading">Available vaccines</h2>
<!-- /wp:heading -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Flu (2026–27): ages 3+</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>COVID-19 updated: ages 5+</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Shingles: ages 50+</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Tdap: ages 7+</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"lv-mono"} -->
<p class="lv-mono">Embedded widget · iframe</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<div class="lv-embed"><iframe title="Vaccine scheduling widget (demo third-party embed)" src="<?php echo esc_url( get_theme_file_uri( 'assets/widget-booking.html' ) ); ?>" style="height:520px" loading="lazy"></iframe></div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
