<?php
/**
 * Title: Hours and Google Maps embed
 * Slug: linden-vale/hours-map
 * Categories: linden-vale
 * Description: Opening-hours table beside a Google Maps iframe embed (third-party widget). Replace the map query with the real address.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading -->
<h2 class="wp-block-heading">Opening hours</h2>
<!-- /wp:heading -->
<!-- wp:table -->
<figure class="wp-block-table"><table><tbody><tr><td>Monday–Friday</td><td>8:00 am – 8:00 pm</td></tr><tr><td>Saturday</td><td>9:00 am – 5:00 pm</td></tr><tr><td>Sunday</td><td>10:00 am – 2:00 pm</td></tr></tbody></table></figure>
<!-- /wp:table -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">123 Example Street (placeholder) · Step-free entrance</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:html -->
<div class="lv-embed"><iframe title="Map of the pharmacy location (placeholder)" src="https://www.google.com/maps?q=Union+Square,+San+Francisco&amp;z=15&amp;output=embed" style="aspect-ratio:4/3" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
