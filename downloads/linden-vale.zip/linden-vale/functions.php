<?php
/**
 * Linden & Vale theme functions.
 *
 * @package linden-vale
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'linden-vale', get_theme_file_uri( 'assets/css/theme.css' ), array(), $ver );
	wp_enqueue_script( 'linden-vale', get_theme_file_uri( 'assets/js/theme.js' ), array(), $ver, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

add_action( 'init', function () {
	register_block_pattern_category( 'linden-vale', array( 'label' => __( 'Linden & Vale (pharmacy)', 'linden-vale' ) ) );
} );
