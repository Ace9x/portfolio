=== Linden & Vale ===
Contributors: Ace Apps
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
License: GPLv2 or later

A clean, clinical Swiss-style block theme for independent pharmacies. Concept theme by Ace Apps. "Linden & Vale" is a fictional business.

== Patterns ==
* Pharmacy hero with task shortcuts (linden-vale/hero)
* Numbered services grid (linden-vale/services)
* Refill request form, demo (linden-vale/refill-form): connect to a HIPAA-compliant portal before launch. It posts nowhere.
* Hours and Google Maps embed (linden-vale/hours-map)
* Booking widget embed (linden-vale/booking-embed): replace the demo iframe with your scheduler's embed code.
* Mint call-to-action band (linden-vale/cta)

== Copyright ==
Inter Tight and IBM Plex Mono: SIL Open Font License 1.1.
Hero image: original image generated for this theme.
